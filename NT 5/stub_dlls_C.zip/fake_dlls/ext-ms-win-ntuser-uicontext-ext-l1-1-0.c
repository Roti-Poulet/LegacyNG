#include <windows.h>

BOOL WINAPI DllMain(HINSTANCE hinst, DWORD reason, LPVOID reserved) {
    return TRUE;
}

/*
  Stub : l'appli veut juste savoir si le process est "immersive"
  On r�pond NON (FALSE), ce qui est g�n�ralement s�r.
*/
__declspec(dllexport)
BOOL WINAPI IsImmersiveProcess(HANDLE hProcess) {
    return FALSE;
}